Rioux Chem Control Box Specs:


2- Layer
.0625"  PCB thickness FR-4
17.180" x 8"
2oz Copper
.015" min Drill
.008" min Trace/Space

Route to shape on board outline layer
2 small routes on route lines layer
1 small score on score lines layer


File Extensions

.GTL		Top Copper
.GTO		Top Silkscreen/Legend
.GTP		Top Pastemask
.GTS		Top Soldermask

.GBL		Bottom Copper
.GBO		Bottom Silkscreen/Legend
.GBS		Bottom Soldermask
.GBP		Bottom Pastemask

.GM17		Board outline
.GM19		Route lines
.GM20		Score Line

.TXT		NC Drill File